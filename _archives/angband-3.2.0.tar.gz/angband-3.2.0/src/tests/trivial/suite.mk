TESTPROGS += trivial/trivial
