#include "angband.h"

void acid_ball_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Acid Ball");
        break;
    case SPELL_DESC:
        var_set_string(res, "Generate an Acid Ball on chosen target.");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(3*p_ptr->lev/2 + 35 + p_ptr->to_d_spell)));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;
        fire_ball(GF_ACID, dir, spell_power(3*p_ptr->lev/2 + 35 + p_ptr->to_d_spell), 2);
        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void acid_bolt_spell(int cmd, var_ptr res)
{
    int dd = 5 + p_ptr->lev / 4;
    int ds = 8;

    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Acid Bolt");
        break;
    case SPELL_DESC:
        var_set_string(res, "Fires a bolt or beam of acid.");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(dd, spell_power(ds), spell_power(p_ptr->to_d_spell)));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;
        fire_bolt_or_beam(
            beam_chance(),
            GF_ACID,
            dir,
            spell_power(damroll(dd, ds) + p_ptr->to_d_spell)
        );
        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void alchemy_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Alchemy");
        break;
    case SPELL_DESC:
        var_set_string(res, "Turns valuable items into gold.");
        break;
    case SPELL_GAIN_MUT:
        msg_print("You gain the Midas touch.");
        break;
    case SPELL_LOSE_MUT:
        msg_print("You lose the Midas touch.");
        break;
    case SPELL_MUT_DESC:
        var_set_string(res, "You can turn ordinary items to gold.");
        break;
    case SPELL_CAST:
        var_set_bool(res, FALSE);
        if (alchemy())
            var_set_bool(res, TRUE);
        break;
    default:
        default_spell(cmd, res);
        break;
    }
}
bool cast_alchemy(void) { return cast_spell(alchemy_spell); }

void alter_reality_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Alter Reality");
        break;
    case SPELL_DESC:
        var_set_string(res, "Recreates current dungeon level.");
        break;
    case SPELL_CAST:
        alter_reality();
        var_set_bool(res, TRUE);
        break;
    default:
        default_spell(cmd, res);
        break;
    }
}

void amnesia_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Amnesia");
        break;
    case SPELL_DESC:
        var_set_string(res, "Attempt to make target monster forget something.");
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        int lvl = p_ptr->lev;
        if (p_ptr->lev > 40)
            lvl += (p_ptr->lev - 40) * 2;

        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;
        project_hook(GF_AMNESIA, dir, lvl, PROJECT_STOP | PROJECT_KILL | PROJECT_REFLECTABLE);
        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void android_ray_gun_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Ray Gun");
        break;
    case SPELL_DESC:
        var_set_string(res, "Fires unresistable damage at chosen foe.");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(5 + (p_ptr->lev+1) / 2)));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;
        
        msg_print("You fire your ray gun.");
        fire_bolt(GF_MISSILE, dir, spell_power(5 + (p_ptr->lev+1) / 2));
        
        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void android_blaster_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Blaster");
        break;
    case SPELL_DESC:
        var_set_string(res, "");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(5 + p_ptr->lev)));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;

        msg_print("You fire your blaster.");
        fire_bolt(GF_MISSILE, dir, spell_power(5 + p_ptr->lev));

        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void android_bazooka_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Bazooka");
        break;
    case SPELL_DESC:
        var_set_string(res, "Fires your bazooka at a nearby monster.");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(25 + p_ptr->lev * 2)));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;

        msg_print("You fire your bazooka.");
        fire_ball(GF_MISSILE, dir, spell_power(25 + p_ptr->lev * 2), 2);

        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void android_beam_cannon_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Beam Cannon");
        break;
    case SPELL_DESC:
        var_set_string(res, "");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(25 + p_ptr->lev * 3)));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;

        msg_print("You fire a beam cannon.");
        fire_beam(GF_MISSILE, dir, spell_power(25 + p_ptr->lev * 3));

        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void android_rocket_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Rocket Launcher");
        break;
    case SPELL_DESC:
        var_set_string(res, "Launches a powerful rocket at your opponent.");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(p_ptr->lev * 7)));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;

        msg_print("You launch a rocket.");
        fire_rocket(GF_ROCKET, dir, spell_power(p_ptr->lev * 7), 2);

        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void animate_dead_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Animate Dead");
        break;
    case SPELL_DESC:
        var_set_string(res, "Resurrects nearby corpse and skeletons. And makes these your pets.");
        break;
    case SPELL_CAST:
        animate_dead(0, p_ptr->pos.y, p_ptr->pos.x);
        var_set_bool(res, TRUE);
        break;
    default:
        default_spell(cmd, res);
        break;
    }
}

static void _awesome_blow(plr_attack_ptr ctx)
{
    int dir = point_step_dir(p_ptr->pos, ctx->mon_pos);
    if (dir != 5)
    {
        int ct = 0;
        int max = 3;
        point_t last = ctx->mon_pos;

        if (p_ptr->pclass == CLASS_RAGE_MAGE)
        {
            if (plr_tim_find(T_BERSERK)) max = 6;
        }
        else if (p_ptr->pclass == CLASS_MAULER && ctx->obj)
        {
            int w = ctx->obj->weight;
            max = MIN(p_ptr->lev/5, w/40);
        }

        for (ct = 0; ct < max; ct++)
        {
            point_t pos = point_step(last, dir);
            
            if (!cave_empty_at(pos))
            {
                int dam = 50;

                if ( mon_at(pos)
                  || cave_have_flag_at(pos, FF_TREE)
                  || cave_at(pos)->feat == feat_rubble
                  || cave_at(pos)->feat == feat_dark_pit )
                {
                    dam = 25;
                }
                msg_format("%^s is wounded.", ctx->mon_name);
                dam = dam * (max - ct);
                ctx->dam_total += dam;
                if (mon_take_hit(ctx->mon->id, dam, &ctx->fear, NULL))
                    ctx->stop = STOP_MON_DEAD;
                break;
            }
            else
            {
                dun_move_mon(cave, ctx->mon, pos);
                last = pos;

                if (ctx->race->flags7 & (RF7_LITE_MASK | RF7_DARK_MASK))
                    p_ptr->update |= PU_MON_LITE;

                Term_fresh();
                Term_xtra(TERM_XTRA_DELAY, delay_animation);
                ctx->stop = STOP_MON_MOVED;
            }
        }
    }
}
void awesome_blow_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Awesome Blow");
        break;
    case SPELL_DESC:
        var_set_string(res, "Attack a monster with a single melee blow. If blow hits, does normal melee damage and propels the monster backwards.");
        break;
    case SPELL_CAST: {
        plr_attack_t ctx = {0};
        ctx.flags = PAC_NO_INNATE | PAC_ONE_BLOW;
        ctx.hooks.after_hit_f = _awesome_blow;
        var_set_bool(res, plr_attack_special_aux(&ctx, 1));
        break; }
    default:
        default_spell(cmd, res);
        break;
    }
}

void banish_evil_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Banish Evil");
        break;
    case SPELL_DESC:
        var_set_string(res, "Attempts to remove a single evil opponent.");
        break;
    case SPELL_GAIN_MUT:
        msg_print("You feel a holy wrath fill you.");
        break;
    case SPELL_LOSE_MUT:
        msg_print("You no longer feel a holy wrath.");
        break;
    case SPELL_MUT_DESC:
        var_set_string(res, "You can send evil creatures directly to Hell.");
        break;
    case SPELL_CAST:
    {
        mon_ptr mon = plr_target_mon();
        mon_race_ptr race;

        var_set_bool(res, FALSE);
        if (!mon)
        {
            msg_print("You sense no evil there!");
            break;
        }
        var_set_bool(res, TRUE);

        race = mon_race(mon);
        if ((race->flags3 & RF3_EVIL) &&
            !(mon->mflag2 & MFLAG2_QUESTOR) &&
            !(race->flags1 & RF1_UNIQUE) &&
            !quests_get_current() &&
            (race->level < randint1(p_ptr->lev+50)) &&
            !(mon->mflag2 & MFLAG2_NOGENO))
        {
            /* Delete the monster, rather than killing it. */
            delete_monster(mon);
            msg_print("The evil creature vanishes in a puff of sulfurous smoke!");
        }
        else
        {
            msg_print("Your invocation is ineffectual!");
            if (one_in_(13)) mon->mflag2 |= MFLAG2_NOGENO;
        }
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}
bool cast_banish_evil(void) { return cast_spell(banish_evil_spell); }

void battle_frenzy_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Battle Frenzy");
        break;
    case SPELL_DESC:
        var_set_string(res, "Gives another bonus to hit and HP, resistance to fear for a while. Hastes you. But decreases AC.");
        break;
    case SPELL_CAST:
    {
        int b_base = spell_power(25);
        int sp_base = spell_power(p_ptr->lev / 2);
        int sp_sides = 20 + p_ptr->lev / 2;

        plr_tim_add(T_BERSERK, randint1(b_base) + b_base);
        plr_tim_add(T_FAST, randint1(sp_sides) + sp_base);

        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void berserk_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Berserk");
        break;
    case SPELL_DESC:
        var_set_string(res, "Enter a berserk frenzy, gaining great combat bonuses, but losing the ability to think clearly.");
        break;
    case SPELL_GAIN_MUT:
        msg_print("You feel a controlled rage.");
        break;
    case SPELL_LOSE_MUT:
        msg_print("You no longer feel a controlled rage.");
        break;
    case SPELL_MUT_DESC:
        var_set_string(res, "You can drive yourself into a berserk frenzy.");
        break;
    case SPELL_CAST:
    {
        msg_print("Raaagh! You feel like hitting something.");
        plr_tim_add(T_BERSERK, 10 + randint1(p_ptr->lev));
        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}
bool cast_berserk(void) { return cast_spell(berserk_spell); }

void bless_spell(int cmd, var_ptr res)
{
    int base = spell_power(12);
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Bless");
        break;
    case SPELL_DESC:
        var_set_string(res, "Gives bonus to hit and AC for a few turns.");
        break;
    case SPELL_INFO:
        var_set_string(res, info_duration(base, base));
        break;
    case SPELL_CAST:
        plr_tim_add(T_BLESSED, randint1(base) + base);
        var_set_bool(res, TRUE);
        break;
    default:
        default_spell(cmd, res);
        break;
    }
}

void bless_weapon_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Bless Weapon");
        break;
    case SPELL_DESC:
        var_set_string(res, "Blesses your current weapon.");
        break;
    case SPELL_CAST:
        var_set_bool(res, bless_weapon());
        break;
    default:
        default_spell(cmd, res);
        break;
    }
}

static dice_t _brain_smash_dice(void)
{
    dice_t dice = {0};
    dice.dd = 2 + p_ptr->lev/5;
    dice.ds = dice.dd;
    dice.base = MAX(p_ptr->lev - 20, 0) + p_ptr->to_d_spell;
    return dice;
}
void brain_smash_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Brain Smash");
        break;
    case SPELL_DESC:
        var_set_string(res, "Gaze intently at a single foe, causing damage, confusion and stunning");
        break;
    case SPELL_INFO: {
        dice_t d = _brain_smash_dice();
        var_set_string(res, info_damage(d.dd, spell_power(d.ds), spell_power(d.base)));
        break; }
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir(&dir)) return;
        fire_ball_hide(
            GF_BRAIN_SMASH,
            dir,
            spell_power(dice_roll(_brain_smash_dice())),
            0
        );
        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void breathe_disintegration_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Breathe Disintegration");
        break;
    case SPELL_DESC:
        var_set_string(res, "A disintegration breath. Not even the dungeon walls can withstand its power!");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(MIN(p_ptr->chp / 6, 150))));
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (!get_fire_dir_aux(&dir, TARGET_DISI)) return;

        stop_mouth();
        msg_print("You breathe disintegration.");
        fire_ball(GF_DISINTEGRATE, dir, 
            spell_power(MIN(p_ptr->chp / 6, 150)), 
            (p_ptr->lev > 40 ? -3 : -2));

        var_set_bool(res, TRUE);
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void breathe_fire_I_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Breathe Fire");
        break;
    case SPELL_DESC:
        var_set_string(res, "Breathes Fire at your opponent.");
        break;
    case SPELL_GAIN_MUT:
        msg_print("You gain the ability to breathe fire.");
        break;
    case SPELL_LOSE_MUT:
        msg_print("You lose the ability to breathe fire.");
        break;
    case SPELL_MUT_DESC:
        var_set_string(res, "You can breathe fire (dam lvl * 2).");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(2 * p_ptr->lev)));
        break;
    case SPELL_COST_EXTRA:
        var_set_int(res, (p_ptr->lev+1)/2);
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (get_fire_dir(&dir))
        {
            stop_mouth();
            msg_print("You breathe fire...");
            fire_ball(GF_FIRE, dir, spell_power(2 * p_ptr->lev), -1 - (p_ptr->lev / 20));
            var_set_bool(res, TRUE);
        }
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}
bool cast_breathe_fire_I(void) { return cast_spell(breathe_fire_I_spell); }

void breathe_fire_II_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Breathe Fire");
        break;
    case SPELL_DESC:
        var_set_string(res, "Breathes Fire at your opponent.");
        break;
    case SPELL_INFO:
        var_set_string(res, info_damage(0, 0, spell_power(p_ptr->chp*2/5)));
        break;
    case SPELL_COST_EXTRA:
        var_set_int(res, p_ptr->lev);
        break;
    case SPELL_CAST:
    {
        int dir = 0;
        var_set_bool(res, FALSE);
        if (get_fire_dir(&dir))
        {
            stop_mouth();
            msg_print("You breathe fire...");
            fire_ball(GF_FIRE, dir, spell_power(p_ptr->chp*2/5), -1 - (p_ptr->lev / 20));
            var_set_bool(res, TRUE);
        }
        break;
    }
    default:
        default_spell(cmd, res);
        break;
    }
}

void building_up_spell(int cmd, var_ptr res)
{
    switch (cmd)
    {
    case SPELL_NAME:
        var_set_string(res, "Building Up");
        break;
    case SPELL_DESC:
        var_set_string(res, "Increases your physical prowess");
        break;
    case SPELL_CAST:
        plr_tim_add(T_GIANT_STRENGTH, 20 + randint1(20));
        var_set_bool(res, TRUE);
        break;
    default:
        default_spell(cmd, res);
        break;
    }
}
