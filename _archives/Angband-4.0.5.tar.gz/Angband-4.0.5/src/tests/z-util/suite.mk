TESTPROGS += z-util/util
