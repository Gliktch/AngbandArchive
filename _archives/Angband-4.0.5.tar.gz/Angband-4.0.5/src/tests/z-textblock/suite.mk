TESTPROGS += z-textblock/textblock
