TESTPROGS += command/lookup
