TESTPROGS += artifact/name
