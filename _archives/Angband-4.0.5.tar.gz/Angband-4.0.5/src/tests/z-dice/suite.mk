TESTPROGS += z-dice/dice
