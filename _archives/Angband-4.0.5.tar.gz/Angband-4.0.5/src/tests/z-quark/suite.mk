TESTPROGS += z-quark/quark
