TESTPROGS += artifact/randname
