TESTPROGS += object/attack
