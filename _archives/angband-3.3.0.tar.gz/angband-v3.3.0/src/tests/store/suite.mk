TESTPROGS += store/store

