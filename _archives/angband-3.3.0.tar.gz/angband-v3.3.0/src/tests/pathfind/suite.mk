TESTPROGS += pathfind/pathfind
